"""Module for kernel tuner cuda-python utility functions."""

import numpy as np

try:
    from cuda.bindings import driver, runtime, nvrtc
except ImportError:
    cuda = None

NVRTC_VALID_CC = np.array(
    [
        "50",
        "52",
        "53",
        "60",
        "61",
        "62",
        "70",
        "72",
        "75",
        "80",
        "87",
        "89",
        "90",
        "90a",
        "100",
        "100f",
        "100a",
        "101",
        "101f",
        "101a",
        "103",
        "103f",
        "103a",
        "120",
        "120f",
        "120a",
        "121",
        "121f",
        "121a",
    ]
)


def cuda_error_check(error):
    """Checking the status of CUDA calls using the NVIDIA cuda-python backend."""
    if isinstance(error, driver.CUresult):
        if error != driver.CUresult.CUDA_SUCCESS:
            _, name = driver.cuGetErrorName(error)
            raise RuntimeError(f"CUDA Driver error: {name.decode()}")
    elif isinstance(error, runtime.cudaError_t):
        if error != runtime.cudaError_t.cudaSuccess:
            _, name = runtime.cudaGetErrorName(error)
            raise RuntimeError(f"CUDA Runtime error: {name.decode()}")
    elif isinstance(error, nvrtc.nvrtcResult):
        if error != nvrtc.nvrtcResult.NVRTC_SUCCESS:
            _, desc = nvrtc.nvrtcGetErrorString(error)
            raise RuntimeError(f"NVRTC error: {desc.decode()}")
    elif isinstance(error, tuple) and len(error) > 0:
        cuda_error_check(error[0])
    else:
        raise RuntimeError(f"unknown error type returned by CUDA: {error!r} (type: {type(error).__name__})")


def to_valid_nvrtc_gpu_arch_cc(compute_capability: str) -> str:
    """Returns a valid Compute Capability for NVRTC `--gpu-architecture=`, as per https://docs.nvidia.com/cuda/nvrtc/index.html#group__options."""
    return max(NVRTC_VALID_CC[NVRTC_VALID_CC <= compute_capability], default="75")
